package com.global.thread;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;



public class AdminThread implements Runnable {

	@Override
	public void run() {
		AdminMenue obj = new AdminMenue();
		obj.menue();
		
	}

}
