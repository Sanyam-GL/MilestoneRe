package com.global.thread;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;




	public class UserThread implements Runnable {

		@Override
		public void run() {
			UserMenue obj = new UserMenue();
			obj.menue();
			
		}

	}
