package com.global;

import java.util.Scanner;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;


public class Runner {
	public static void main(String[] args)
	{
		
		DBconnection database = new DBconnection();
		
		database.getConnection();
		UserMenue umenu=new UserMenue();
		AdminMenue amenu = new AdminMenue();
		
		try {
		Scanner sc = new Scanner(System.in);
			System.out.println("Press 1 for admin ");
			System.out.println("Press 2 for user ");
			int ch = sc.nextInt();
			
			AdminThread adminth = new AdminThread();
			UserThread userth = new UserThread();
			
			if(ch==1)
			{
				adminth.run();
			}
			else if(ch==2)
			{
				userth.run();
			}
			else
			{
				System.out.println("Enter a valid input");
				main(new String[] {""});
				
			}
		}
		catch(Exception e)
		{
			System.out.println("Enter a valid input");
			main(new String[] {""});
		}	
		
		
	}

}
