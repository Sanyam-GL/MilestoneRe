package com.global.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;


public class ProductRepo {
	
	 AdminMenue a_menu=new AdminMenue();
	
	//----------add product ------------------
		public void addProduct(ProductTO product)
		{
			try {
				Connection connection  = DBconnection.getConnection();
	            PreparedStatement statement = connection.prepareStatement("insert into product values(?, ?, ?,?)");
	            statement.setString(1, product.getProductName());
	            statement.setString(2, product.getProductID());
	            statement.setString(3, product.getCategory());
	            statement.setString(4, product.getPrice());
	            
	            
	           
	            statement.executeUpdate();
	            System.out.println("Successfully added product");
	          
	            a_menu.menue();
	            
	        } catch (Exception e) {
	            System.out.println("Product not added");
	            a_menu.menue();
	        }
		}
		
		//-----------list of products in store ----------------
		public void list()
		{
			
			Connection connection  = DBconnection.getConnection();
			try {
	            PreparedStatement statement = connection.prepareStatement("select * from product");
	            ResultSet result = statement.executeQuery();
	            while (result.next() == true) {
	                System.out.println("Name :" + result.getString(1));
	                System.out.println("ID : "+result.getString(2));
	                System.out.println("Category :" +result.getString(3));
	                System.out.println("Price : " +result.getString(4));
	                System.out.println("-------------------");
	                
	                a_menu.menue();
	               
	            }
	           
	        } catch (Exception e) {
	            System.out.println("inside bookList catch");
	            a_menu.menue();
		}
		}
		
		//----------------delete------------------------------
		public void delete(String name )
		{
			//Scanner sc = new Scanner(System.in);
			Connection connection  = DBconnection.getConnection();
			try {
			PreparedStatement statement;
			
			//System.out.println("Enter Product name you want to delete");
			//String name= sc.next();
			
			statement = connection.prepareStatement("select name from product where name = ?");
	        statement.setString(1, name);
	        
	        ResultSet resultset2 =  statement.executeQuery();
	        if(resultset2.next() == true) {
	        	statement = connection.prepareStatement("delete from product where name=?");
				statement.setString(1, name);
				statement.executeUpdate();
				
				System.out.println("The Product has been removed");
				
				a_menu.menue();
	        	
	        }
	        else
	        {
	        	System.out.println("Their is no such book in the Library");
	        	AdminMenue a_menu=new AdminMenue();
				a_menu.menue();
	        }	
			}
			catch (Exception e) {
	            System.out.println("inside delete book catch");
	            a_menu.menue();
		}
		}
		
		//--------------- search -------------------------
		public void search(String name)
		{
			try
	        {
				Connection connection  = DBconnection.getConnection();
	            PreparedStatement statement=connection.prepareStatement("select * from product where name = ?");
	            
	            boolean isFound=false;
	            
	           
	            statement.setString(1,name);
	            
	            ResultSet result=statement.executeQuery();
	            while(result.next()==true)
	            {
	            	
	                System.out.println(result.getString(1) + "       " +result.getString(2) + "     "+result.getString(3));
	                isFound = true;
	                
	            }
	            if(isFound==false)
	            {
	                
	                System.out.println("Product out of stock");
	                AdminMenue obj = new AdminMenue();
	                obj.menue();
	            }
	             
	            
	            
	        }
	        catch(Exception e)
	        {
	            System.out.println("inside ProductSearch catch");
	            AdminServices obj = new AdminServices();
	            obj.search();
	        }
		}
		
		//--------------- Order-------------------------
		
		public void order(String name, String id )
		{
	        UserMenue u_menu=new UserMenue();

			try
			{
				Connection connection  = DBconnection.getConnection();
	            PreparedStatement statement = connection.prepareStatement("insert into p_order values(?, ?)");
	            statement.setString(1, name);
	            statement.setString(2, id);
	        
	            
	           
	            statement.executeUpdate();
	            System.out.println("Successfully ordered");
	            u_menu.menue();
			}
			catch(Exception e)
			{
				System.out.println("Inside order catch ");
				u_menu.menue();
				
			}
		}
		
		//------------------ update---------------------------------
		public void update(String name1, String name2)
		{
			try
			{
				Connection connection  = DBconnection.getConnection();
	            PreparedStatement statement = connection.prepareStatement("Update product set price =? where price = ?");
	            statement.setString(1, name2);
	            statement.setString(2, name1);
	        
	            
	           
	            statement.executeUpdate();
	            System.out.println("Product Price Updated sucessfully");
	            AdminMenue a_menu=new AdminMenue();
	            a_menu.menue();
			}
			catch(Exception e)
			{
				System.out.println("Due to some error the user got logged out plz login again");
				AdminMenue a_menu=new AdminMenue();
	            a_menu.menue();
			}
			
		}
		
		//---- orderList-------------------
		
		public void orderList(String name)
		{
			
			Connection connection  = DBconnection.getConnection();
			try {
	            PreparedStatement statement = connection.prepareStatement("select * from p_order where u_name =?");
	            statement.setString(1, name);
	            ResultSet result = statement.executeQuery();
	            while (result.next() == true) {
	                System.out.println("Product Name :" + result.getString(1));
	                System.out.println("-------------------");
	               
	            }
	           
	        } catch (Exception e) {
	            System.out.println("inside bookList catch");
		}
		}
		
		//--------------------------------------------------------

		public void descList()
		{
			
			Connection connection  = DBconnection.getConnection();
			try {
	            PreparedStatement statement = connection.prepareStatement("SELECT * FROM product ORDER BY price DESC;");
	            ResultSet result = statement.executeQuery();
	            while (result.next() == true) {
	                System.out.println("Name :" + result.getString(1));
	                System.out.println("ID : "+result.getString(2));
	                System.out.println("Category :" +result.getString(3));
	                System.out.println("Price : " +result.getString(4));
	                System.out.println("-------------------");
	               
	            }
	           
	        } catch (Exception e) {
	            System.out.println("inside bookList catch");
		}
		}
		
		//-----------------------------------------------------------
		
		public void ascList()
		{
			
			Connection connection  = DBconnection.getConnection();
			try {
	            PreparedStatement statement = connection.prepareStatement("SELECT * FROM product ORDER BY price ASC;");
	            ResultSet result = statement.executeQuery();
	            while (result.next() == true) {
	                System.out.println("Name :" + result.getString(1));
	                System.out.println("ID : "+result.getString(2));
	                System.out.println("Category :" +result.getString(3));
	                System.out.println("Price : " +result.getString(4));
	                System.out.println("-------------------");
	               
	            }
	           
	        } catch (Exception e) {
	            System.out.println("inside bookList catch");
		}
		}
		
		//-----------All ordered list for admin-------------
		public void orderedList()
		{
			
			Connection connection  = DBconnection.getConnection();
			try {
	            PreparedStatement statement = connection.prepareStatement("select * from p_order");
	            ResultSet result = statement.executeQuery();
	            while (result.next() == true) {
	                System.out.println("Name :" + result.getString(1));
	                System.out.println("User_Name : "+result.getString(2));
	                System.out.println("-------------------");
	               
	            }
	           
	        } catch (Exception e) {
	            System.out.println("inside orderedList catch");
		}
		}
		
		//----------------- Block a user----------------------
		
		public void blockUser(String name )
		{
			
			Connection connection  = DBconnection.getConnection();
			try {
	            PreparedStatement statement = connection.prepareStatement("Update user set block = 1 where uname = ?");
	       
	            statement.setString(1, name);
	           
	        
	            
	           
	            statement.executeUpdate();
	            System.out.println("User Blocked ");
	            AdminMenue a_menu=new AdminMenue();
	            a_menu.menue();
	               
	            
	           
	        } catch (Exception e) {
	            System.out.println("inside userBlock catch");
	            AdminMenue a_menu=new AdminMenue();
	            a_menu.menue();
		}
		}
		
		public void productDetail(String name)
		{
			
				Connection connection  = DBconnection.getConnection();
				try {
		            PreparedStatement statement = connection.prepareStatement("select * from product where id= ?");
		            statement.setString(1, name);
		            ResultSet result = statement.executeQuery();
		            while (result.next() == true) {
		                System.out.println("Name :" + result.getString(1));
		                System.out.println("ID : "+result.getString(2));
		                System.out.println("Category :" +result.getString(3));
		                System.out.println("Price : " +result.getString(4));
		                System.out.println("-------------------");
		                
		                a_menu.menue();
		               
		            }
		           
		        } catch (Exception e) {
		            System.out.println("inside productList by id catch");
		            a_menu.menue();
			}
			
		}

}
