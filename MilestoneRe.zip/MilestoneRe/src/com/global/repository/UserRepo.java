//To send to database 

package com.global.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;

public class UserRepo {
	

	UserMenue u_menue = new UserMenue();

	//----------register user-------------------
	public void register(UserTo user)
	{
		Connection connection  = DBconnection.getConnection();
		try {
		PreparedStatement statement = connection.prepareStatement("insert into user values(?, ?, ?,?,?)");
        statement.setString(1, user.getUname());
        statement.setString(2, user.getPass());
        statement.setString(3, user.getfName());
        statement.setString(4, user.getlName());
        statement.setInt(5, 0);
        statement.executeUpdate();
        
        System.out.println("Successfully registred");
        u_menue.menue();
       
    }
    catch (Exception e) {
        System.out.println("inside regsiter of UserRepository");
    }
	}
	//--------login user----------------------------------
	
	public void login(String uname, String pass)
	{
		Connection connection  = DBconnection.getConnection();
		try
        {
            PreparedStatement statement=connection.prepareStatement("select * from user where uname = ? and password = ? and block =0");
            statement.setString(1,uname);
            statement.setString(2,pass);
            
            ResultSet result=statement.executeQuery();
            if(result.next()==true)
            {
                System.out.println("Login sucessfully");
                return;
                
            
            }
            else
            {
                System.out.println("user not found or blocked by the admin");
                u_menue.menue();
                
                
            }
            
        }
        catch(Exception e)
        {
            System.out.println("inside login catch");
            
        }
	}
	

}
