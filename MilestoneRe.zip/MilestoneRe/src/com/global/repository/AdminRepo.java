//To send to database 

package com.global.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;


public class AdminRepo {
	

	AdminMenue a_menue = new AdminMenue();

	//--------- register admin -----------------
	public void register(UserTo user)
	{
		Connection connection  = DBconnection.getConnection();
		try {
		PreparedStatement statement = connection.prepareStatement("insert into admin values(?, ?, ?,?)");
        statement.setString(1, user.getUname());
        statement.setString(2, user.getPass());
        statement.setString(3, user.getfName());
        statement.setString(4, user.getlName());
        statement.executeUpdate();
        
        System.out.println("Successfully registred");
        a_menue.menue();
       
    }
    catch (Exception e) {
        System.out.println("inside regsiter of UserRepository");
    }
	}
	
	//-------- 
	public void login(String uname, String pass)
	{
		Connection connection  = DBconnection.getConnection();
		try
        {
            PreparedStatement statement=connection.prepareStatement("select * from admin where uname = ? and password = ?");
            statement.setString(1,uname);
            statement.setString(2,pass);
            
            ResultSet result=statement.executeQuery();
            if(result.next()==true)
            {
                System.out.println("Login sucessfully");
                return;
                
            
            }
            else
            {
                System.out.println("user not found");
                a_menue.menue();
                
                
            }
            
        }
        catch(Exception e)
        {
            System.out.println("inside login catch");
            
        }
	}
	

}
