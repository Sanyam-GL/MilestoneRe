package com.global.database;
import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBconnection {
    
    static Connection connection = null;
    
    public static  Connection getConnection()
    {
        
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookshop", "root", "root");    
          // System.out.println("Connected");
        }
        
        catch (Exception e) {
            System.out.println("inside getConnection catch");
            e.printStackTrace();
        }
        return connection;    
    }
    }