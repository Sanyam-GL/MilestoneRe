package com.global.To;

import java.util.Scanner;

import com.global.database.*;
import com.global.Runner;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;


public class AdminMenue {
	
	Scanner sc = new Scanner(System.in);
	Runner obj = new Runner();
	
	
	
	public void menue()
	{
		try {
			
			AdminServices aService = new AdminServices();
			
		System.out.println("Press 1 to register as Admin ");
		System.out.println("Press 2 to Login as Admin");
		System.out.println("Press 0 to return to main menue");
		int c = sc.nextInt();
		
		if(c==1)
		{
			
			aService.register();
		}
		else if(c==2)
		{
			try {
			aService.login();
			//------- after login --------
			System.out.println("Enter 1 to List Products ");
			System.out.println("Enter 2 to search Product ");
			System.out.println("Enter 3 to add Product ");
			System.out.println("Enter 4 to delete Product ");
			System.out.println("Enter 5 to Update Product");
			System.out.println("ENter 6 to see all the orders");
			System.out.println("Enter 7 to block a user ");
			System.out.println("Enter 8 to see product detail by id ");
			System.out.println("Enter 0 to logout");
			
			int ch= sc.nextInt();
			
			if(ch==1)
			{
				aService.list();
				obj.main(null);
			}
			else if(ch==2)
			{
				aService.search();
				obj.main(null);
			}
			else if(ch==3)
			{
				aService.addBook();
				obj.main(null);
			}
			else if(ch==4)
			{
				aService.deleteBook();
				obj.main(null);
			}
			else if(ch==5)
			{
				aService.update();
				obj.main(null);
			}
			else if(ch==6)
			{
				aService.orderedList();
				obj.main(null);
			}
			else if(ch==7)
			{
				aService.blockUser();
				obj.main(null);
			}
			else if(ch==8)
			{
				aService.productDetail();
				obj.main(null);
			}
			else if(ch==0)
			{
				obj.main(null);
			}
			else
			{
				aService.login();
			}
			
		}
			catch(Exception e)
			{
				System.out.println("Please enter a valid input ");
				aService.login();
			}
		}
		else if(c==0)
		{
			
			obj.main(null);
		}
		
		else
		{
			menue();
		}
		
		}
		catch(Exception e)
		{
			System.out.println("Please enter a valid input");
		
			obj.main(null);
			
		}
		
		
		
		
	}

}
