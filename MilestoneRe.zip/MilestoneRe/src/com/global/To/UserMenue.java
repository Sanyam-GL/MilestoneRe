package com.global.To;

import java.util.Scanner;

import com.global.database.*;
import com.global.Runner;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;

public class UserMenue {
	
	
	
	UserService uService = new UserService();
	public void menue()
	{
		Scanner sc = new Scanner(System.in);
		Runner obj = new Runner();
		System.out.println("Press 1 to register as User ");
		System.out.println("Press 2 to Login as User");
		System.out.println("Press 0 to return to the main menue ");
		
		int c = sc.nextInt();
		
		switch(c)
		{
		case 1:
			uService.register();
			break;
		case 2:
			uService.login();
			System.out.println("Enter 1 to List Products ");
			System.out.println("Enter 2 to search any Product ");
			System.out.println("Enter 3 to Order any product ");
			System.out.println("Enter 4 to see your order List");
			System.out.println("Enter 5 to List product byu price from high to low  ");
			System.out.println("Enter 6 to List product byu price from low to high  ");
			System.out.println("Enter 0 to logout");
			int ch= sc.nextInt();
			
			switch(ch)
			{
			case 1:
				uService.list();
				break;
			case 2:
				uService.search();
				break;
			case 3:
				uService.order();
				break;
			case 4:
				uService.orderList();
				break;
			case 5:
				uService.descList();
				break;
			case 6:
				uService.ascList();
			case 0:
				obj.main(new String[] {""});
				break;
			}
			
			break;
			
		case 0:
			obj.main(new String[] {""});
			break;
			
			
		}
		
		
	}

}
