package com.global.To;

public class AdminTo {
	
	public AdminTo()
	{
		
	}
	
	public AdminTo(String uname, String pass, String fName, String lName) {
		super();
		this.uname = uname;
		this.pass = pass;
		this.fName = fName;
		this.lName = lName;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	private String uname;
	private String pass;
	private String fName;
	private String lName;
	
	

}
