package com.global.To;

public class ProductTO {
	
	public ProductTO()
	{
		
	}
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public ProductTO(String productName, String productID, String category, String price) {
		super();
		this.productName = productName;
		this.productID = productID;
		this.category = category;
		this.price = price;
	}
	private String productName;
	private String productID;
	private String category;
	private String price;

}
