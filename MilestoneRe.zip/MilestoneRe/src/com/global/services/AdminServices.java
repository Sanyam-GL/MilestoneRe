package com.global.services;

import java.util.Scanner;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;


public class AdminServices {
	

	Scanner sc=new Scanner(System.in);
	
	ProductRepo productRepo = new ProductRepo();
	
	//----------register-----------------
	
	public void register()
	{
		UserTo user = new UserTo();
		UserRepo  userRepo = new  UserRepo();
		AdminRepo adminRepo = new AdminRepo();
		System.out.println("Enter username");
		
		String uname = sc.next();
		
		System.out.println("Enter Password");
		String pass = sc.next();
		
		System.out.println("Enter FirstName");
		String fName = sc.next();
		
		System.out.println("Enter LastName");
		String lName = sc.next();
		
		user= new UserTo(uname, pass, fName, lName);
		adminRepo.register(user);
		
	}
	//-------login------------------

	public void login() {
		
		AdminRepo  adminRepo = new  AdminRepo();
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter username ");
		String uname = sc.next();
		
		System.out.println("Enter password");
		String pass = sc.next();
		
		adminRepo.login(uname, pass);
		return;
		
	}
	//-------------------
	public void list()
	{
		
		productRepo.list();
	}
	
	//--------------------------
	public void search()
	{
		
        System.out.println("enter product name");
        String name = sc.next();
		productRepo.search(name);
	}
	//--------------------
	public void addBook()
	{
		ProductTO product = new ProductTO();
		
		
		
		System.out.println("Enter Product Name ");
		String pname = sc.next();
		System.out.println("Enter ProductID");
		String id = sc.next();
		System.out.println("Enter Category");
		String cat= sc.next();
		System.out.println("Enter Price");
		String price= sc.next();
		
		
		
		product = new ProductTO(pname,id,cat,price);
		productRepo.addProduct(product);	
		
	}
	
	public void deleteBook()
	{
		System.out.println("Enter product name you want to delete");
		String name = sc.next();
		productRepo.delete(name);
	}
	//---------------
	
	public void update()
	{
		System.out.println("Enter product Price to be update ");
		String productName= sc.next();
		System.out.println("Enter new Price to replace");
		String rName = sc.next();
		productRepo.update(productName,rName);
	}
	
	public void orderedList()
	{
		
		productRepo.orderedList();
	}
	
	public void blockUser()
	{
		System.out.println("Enter username of user you want to block");
		String uname = sc.next();
		productRepo.blockUser(uname);
	}
	
	public void productDetail()
	{
		System.out.println("Enter product Id");
		String id = sc.next();
		productRepo.productDetail(id);
	}
	

}
