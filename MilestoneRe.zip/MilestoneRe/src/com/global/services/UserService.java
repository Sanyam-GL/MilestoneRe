package com.global.services;

import java.util.Scanner;

import com.global.database.*;
import com.global.To.*;
import com.global.services.*;
import com.global.repository.*;
import com.global.thread.*;


public class UserService {
	

	//---------Register------------
	public void register()
	{
		Scanner sc=new Scanner(System.in);
		UserTo user = new UserTo();
		UserRepo  userRepo = new  UserRepo();
		
		System.out.println("Enter username");
		String uname = sc.next();
		
		System.out.println("Enter Password");
		String pass = sc.next();
		
		System.out.println("Enter FirstName");
		String fName = sc.next();
		
		System.out.println("Enter LastName");
		String lName = sc.next();
		
		user= new UserTo(uname, pass, fName, lName);
		userRepo.register(user);
		
	}
	
//--------------------Login----------------------
	public void login() {
		
		UserRepo  userRepo = new  UserRepo();
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter username ");
		String uname = sc.next();
		
		System.out.println("Enter password");
		String pass = sc.next();
		
		userRepo.login(uname, pass);
		return;
		
	}
	//----------------------
	public void list()
	{
		ProductRepo product = new ProductRepo();
		product.list();
	}
	//-------------------------------
	public void search()
	{
		Scanner sc=new Scanner(System.in);
        System.out.println("enter book name");
        String name = sc.next();
        ProductRepo product = new ProductRepo();
		product.search(name);
	}
	//-------------------------------
	public void order()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Product name you want to order");
		String name = sc.next();
		System.out.println("Enter your username for verification ");
		String id = sc.next();
		ProductRepo product = new ProductRepo();
		product.order(name, id);
		
		
	}
	//-------------
	public void orderList() {
		System.out.println("Enter your username for verification");
		
		Scanner sc=new Scanner(System.in);
		String name = sc.next();
		ProductRepo product = new ProductRepo();
		product.orderList(name);
	}
	//-------------------------------
	public void descList()
	{
		ProductRepo product = new ProductRepo();
		product.descList();
	}
	//-------------------------------------
	public void ascList()
	{
		ProductRepo product = new ProductRepo();
		product.ascList();
	}
	//------------------------------

}
